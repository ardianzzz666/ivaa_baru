var Project = {
    basePath : {},
    params: {}
};