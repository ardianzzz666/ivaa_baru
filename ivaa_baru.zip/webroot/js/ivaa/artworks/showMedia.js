//create by : andi@ontelstudio.com
$(document).ready(function(){

    $(function(){
            $('a#medium-box').click(function(){
                    $('#medium-list').show(500);
            });
            $('a#close-medium').click(function(){
                    $('#medium-list').hide(200);
            });
        });


});

